<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
class Consulta_cnpj_receita extends CI_Controller {
	function __construct() {
		parent::__construct ();
		$this->load->helper ( 'cnpj_receita_helper' );
	}
	public function index() {
		$data ['captcha'] = get_captcha_cnpj_receita ();
		$this->load->view ( 'consulta_cnpj_receita', $data );
	}
	public function consulta_cnpj() {
		$cnpj = $_POST ['cnpj'];
		$captcha = $_POST ['captcha'];
		
		$return = get_cnpj_receita ( $cnpj, $captcha );
		if (! $return) {
			redirect ( base_url ( "consulta_cnpj_receita" ) );
		}
		var_dump ( $return );
	}
}
