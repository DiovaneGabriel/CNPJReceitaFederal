<img src='<?php echo base_url($captcha)?>' />
<form action="<?php echo base_url('consulta_cnpj_receita/consulta_cnpj')?>" method="POST">
	captcha <input size="8" maxlength="6" name="captcha"> cnpj <input
		size="16" maxlength="14" name="cnpj"> <input type="submit">
</form>